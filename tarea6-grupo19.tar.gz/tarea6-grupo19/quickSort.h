#ifndef quickSort_H
#define quickSort_H

void quick_Sort(int[], int, int);
int  partition (int[], int, int);
void capacidad (int[], int, int);
void agregar   (int[], int);

#endif